// Nama  : Zelsya Rizqita Rahmadhini
// NIM   : 2409116022
// KELAS : A 2024

package com.mycompany.koleksifashion.service;

import com.mycompany.koleksifashion.model.*;
import java.util.*;
import java.util.stream.Collectors;

public class FashionService {
    private final List<Item> items = new ArrayList<>();
    private int seq = 1;

    public FashionService() {
        seed10Item(); 
    }

    public void tambah(String nama, String kategori, String ukuran, String warna, String brand, int tahun) {
        String kat = kategori == null ? "" : kategori.trim();
        Item obj;
        if (kat.equalsIgnoreCase("pakaian")) {
            obj = new Pakaian(seq++, nama, ukuran, warna, brand, tahun, "Katun");
        } else if (kat.equalsIgnoreCase("aksesoris")) {
            obj = new Aksesoris(seq++, nama, ukuran, warna, brand, tahun, "Umum");
        } else {
            obj = new Item(seq++, nama, kat.isEmpty() ? "Lainnya" : kategori, ukuran, warna, brand, tahun);
        }
        items.add(obj);
    }

    public List<Item> semua() {
        return new ArrayList<>(items);
    }

    public List<Item> cari(String q) {
        if (q == null || q.isBlank()) return List.of();
        String s = q.trim();

        try {
            int id = Integer.parseInt(s);
            Item one = byId(id);
            return one == null ? List.of() : List.of(one);
        } catch (NumberFormatException ignore) {}

        String lower = s.toLowerCase();
        return items.stream()
                .filter(it -> it.getNama().toLowerCase().contains(lower))
                .collect(Collectors.toList());
    }

    public Item byId(int id) {
        return items.stream().filter(it -> it.getId() == id).findFirst().orElse(null);
    }

    public boolean update(int id, String nama, String kategori, String ukuran, String warna, String brand, Integer tahun) {
        Item it = byId(id);
        if (it == null) return false;

        if (nama != null && !nama.isBlank()) it.setNama(nama);
        if (kategori != null && !kategori.isBlank()) it.setKategori(kategori);
        if (ukuran != null && !ukuran.isBlank()) it.setUkuran(ukuran);
        if (warna != null && !warna.isBlank()) it.setWarna(warna);
        if (brand != null && !brand.isBlank()) it.setBrand(brand);
        if (tahun != null && tahun >= 0) it.setTahun(tahun);

        return true;
    }
    
    public boolean hapus(int id) {
        return items.removeIf(it -> it.getId() == id);
    }

    public List<Item> filterKategori(String kategori) {
        if (kategori == null) return List.of();
        String k = kategori.trim().toLowerCase();
        return items.stream()
                .filter(it -> it.getKategori().toLowerCase().equals(k))
                .collect(Collectors.toList());
    }

    private void seed10Item() {
        tambah("Jaket Denim",     "Outer",     "M",   "Navy",      "Levi's",       2022);
        tambah("Sneakers Canvas", "Sepatu",    "42",  "Putih",     "Converse",     2021);
        tambah("Kaos Graphic",    "Atasan",    "L",   "Hitam",     "Uniqlo",       2023);
        tambah("Celana Chino",    "Bawahan",   "32",  "Khaki",     "H&M",          2022);
        tambah("Dress Batik",     "Atasan",    "M",   "Maroon",    "Lokal",        2023);
        tambah("Hoodie Oversize", "Outer",     "L",   "Abu",       "Zara",         2024);
        tambah("Topi Bucket",     "Aksesoris", "All", "Cream",     "Columbia",     2020); 
        tambah("Rok Plisket",     "Bawahan",   "M",   "Dusty Pink","Stradivarius", 2023);
        tambah("Cardigan Rajut",  "Outer",     "S",   "Hijau",     "Pull&Bear",    2021);
        tambah("Loafers Kulit",   "Sepatu",    "41",  "Cokelat",   "Pedro",        2022);
    }
}
