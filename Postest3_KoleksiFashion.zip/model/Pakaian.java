// Nama  : Zelsya Rizqita Rahmadhini
// NIM   : 2409116022
// KELAS : A 2024

package com.mycompany.koleksifashion.model;

public class Pakaian extends Item {
    private String bahan;  

    public Pakaian(int id, String nama, String ukuran, String warna, String brand, int tahun, String bahan) {
        super(id, nama, "Pakaian", ukuran, warna, brand, tahun);
        this.bahan = bahan;
    }
    
    public String getBahan() { return bahan; }
    public void setBahan(String bahan) { this.bahan = bahan; }

    @Override
    public String detailTambahan() {
        return "Bahan: " + (bahan == null || bahan.isBlank() ? "-" : bahan);
    }
}

   
