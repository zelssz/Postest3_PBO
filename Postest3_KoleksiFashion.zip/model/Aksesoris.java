// Nama  : Zelsya Rizqita Rahmadhini
// NIM   : 2409116022
// KELAS : A 2024

package com.mycompany.koleksifashion.model;

public class Aksesoris extends Item {
    private String jenis;  
 
    public Aksesoris(int id, String nama, String ukuran, String warna, String brand, int tahun, String jenis) {
        super(id, nama, "Aksesoris", ukuran, warna, brand, tahun);
        this.jenis = jenis;
    }

    public String getJenis() { return jenis; }
    public void setJenis(String jenis) { this.jenis = jenis; }

    @Override
    public String detailTambahan() {
        return "Jenis: " + (jenis == null || jenis.isBlank() ? "-" : jenis);
    }
}

